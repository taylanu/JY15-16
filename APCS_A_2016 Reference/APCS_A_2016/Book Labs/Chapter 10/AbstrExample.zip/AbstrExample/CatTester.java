public class CatTester
{
   public static void main(String[]arg)
   {
      Cat x = new Cat("black");
      System.out.println(x);
      x.move();
      x.breed();
   }
}