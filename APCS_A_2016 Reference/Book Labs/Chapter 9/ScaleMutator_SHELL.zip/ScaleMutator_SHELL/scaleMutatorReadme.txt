The Great Scale Mutator Lab

Navigate to the ScaleMutator_SHELL folder
Open up scaleMutator.java and scaleMutatorDriver.java

Complete the methods in scaleMutator, and test them by running ScaleMutatorDriver

NOTE:
if you want to write your scale out to a MIDI file, it will create it in the same folder as this lab.
You can play the MIDI file from most media players.
You can not write out to a MIDI file if one of the same name is already opened in a media player.

For those that do not want graphics, a text only version is available in:

text version/scaleMutatorSHELL.java 
