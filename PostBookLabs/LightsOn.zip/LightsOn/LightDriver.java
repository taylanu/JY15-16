   
    public class LightDriver
   {
   
       public static void main(String[]arg)
      {
      
      
      }
   }