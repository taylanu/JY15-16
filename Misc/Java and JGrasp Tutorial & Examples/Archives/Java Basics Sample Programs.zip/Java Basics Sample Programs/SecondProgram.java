public class SecondProgram
{
   public static void main(String [] arg)
   {
      int num = 5;
      double x = 4.5;
      System.out.println("Our integer is " + num + " and our real is " + x );
   }
}