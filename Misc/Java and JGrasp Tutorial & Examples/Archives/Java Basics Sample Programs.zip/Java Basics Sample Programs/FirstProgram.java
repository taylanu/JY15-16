public class FirstProgram
{
   public static void main(String [] arg)
   {
      System.out.println("Hello World.");
   }
}
